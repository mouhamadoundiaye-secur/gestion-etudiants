// ===== Utile/app.js — Orchestrateur principal =====
// C'est ici que tous les modules sont importés et que les événements sont branchés.

import {
  btnNouvelEtudiant, btnFermerForm, btnAnnulerForm, btnSauvegarder,
  btnOuvrirRestore, btnFermerRestore, btnRestaurerSelec, btnSupprimerSelec,
  checkAll, searchInput, overlayForm, overlayRestore,
  formId, formNom, formPrenom, formEmail, formIndicatif, formTelephone, formRole,
  errNom, errPrenom, errEmail, errTel, errRole
} from "../DOM/element.js";

import { etudiants, corbeille } from "../Stores/taskStores.js";

import {
  ajouterEtudiant, modifierEtudiant,
  restaurerEtudiant, supprimerDefinitivement,
  emailExiste, filtrerEtudiants
} from "../Services/taskService.js";

import { afficherTableau } from "../UI/tasksRenderer.js";
import { afficherCorbeille, getIdsCoches, mettreAJourActionsDrawer } from "../UI/statsRenderer.js";
import { afficherToast } from "../UI/messageRenderer.js";
import {
  ouvrirOverlay, fermerOverlay, viderErreurs,
  ouvrirFormulaireAjout, ouvrirFormulaireModif
} from "../UI/modalRenderer.js";

// ===== VALIDATION ET SOUMISSION DU FORMULAIRE =====
function soumettreFormulaire() {
  viderErreurs();

  var nom       = formNom.value.trim();
  var prenom    = formPrenom.value.trim();
  var email     = formEmail.value.trim();
  var indicatif = formIndicatif.value;
  var telephone = formTelephone.value.trim();
  var role      = formRole.value;
  var idStr     = formId.value;
  var id        = idStr !== "" ? parseInt(idStr) : null;

  var valide = true;

  if (nom === "") {
    errNom.textContent = "Le nom est obligatoire.";
    valide = false;
  }

  if (prenom === "") {
    errPrenom.textContent = "Le prénom est obligatoire.";
    valide = false;
  }

  var regexEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (email === "") {
    errEmail.textContent = "L'email est obligatoire.";
    valide = false;
  } else if (!regexEmail.test(email)) {
    errEmail.textContent = "Format d'email invalide.";
    valide = false;
  } else if (emailExiste(email, id)) {
    errEmail.textContent = "Cet email est déjà utilisé.";
    valide = false;
  }

  if (telephone === "") {
    errTel.textContent = "Le téléphone est obligatoire.";
    valide = false;
  }

  if (role === "") {
    errRole.textContent = "Veuillez choisir une formation.";
    valide = false;
  }

  if (!valide) return;

  var donnees = { nom, prenom, email, indicatif, telephone, role };

  if (id === null) {
    ajouterEtudiant(donnees);
    fermerOverlay("overlayForm");
    afficherTableau(etudiants);
    afficherToast("✅ Étudiant ajouté avec succès !");
  } else {
    modifierEtudiant(id, donnees);
    fermerOverlay("overlayForm");
    afficherTableau(etudiants);
    afficherToast("✅ Étudiant modifié avec succès !");
  }
}

// ===== DRAWER : RESTAURER LES COCHÉS =====
function restaurerSelectionnes() {
  var ids = getIdsCoches();
  if (ids.length === 0) return;
  for (var i = 0; i < ids.length; i++) {
    restaurerEtudiant(ids[i]);
  }
  afficherTableau(etudiants);
  afficherCorbeille();
  afficherToast("↩ Étudiant(s) restauré(s) avec succès !");
}

// ===== DRAWER : SUPPRIMER DÉFINITIVEMENT LES COCHÉS =====
function supprimerDefinitivementSelectionnes() {
  var ids = getIdsCoches();
  if (ids.length === 0) return;
  for (var i = 0; i < ids.length; i++) {
    supprimerDefinitivement(ids[i]);
  }
  afficherCorbeille();
  afficherToast("🗑 Suppression définitive effectuée.");
}

// ===== DRAWER : COCHER / DÉCOCHER TOUT =====
function toggleTousCheckboxes() {
  var etatGlobal = checkAll.checked;
  var checks = document.querySelectorAll(".check-restore");
  for (var i = 0; i < checks.length; i++) {
    checks[i].checked = etatGlobal;
  }
  mettreAJourActionsDrawer();
}

// ===== INITIALISATION AU CHARGEMENT DE LA PAGE =====
document.addEventListener("DOMContentLoaded", function () {

  // Affichage initial du tableau
  afficherTableau(etudiants);

  // Nouveau étudiant → ouvrir popup vide
  btnNouvelEtudiant.addEventListener("click", function () {
    ouvrirFormulaireAjout();
  });

  // Fermer / annuler le popup formulaire
  btnFermerForm.addEventListener("click", function () {
    fermerOverlay("overlayForm");
  });

  btnAnnulerForm.addEventListener("click", function () {
    fermerOverlay("overlayForm");
  });

  // Enregistrer (ajout ou modif)
  btnSauvegarder.addEventListener("click", function () {
    soumettreFormulaire();
  });

  // Ouvrir le drawer corbeille
  btnOuvrirRestore.addEventListener("click", function () {
    afficherCorbeille();
    checkAll.checked = false;
    ouvrirOverlay("overlayRestore");
  });

  // Fermer le drawer
  btnFermerRestore.addEventListener("click", function () {
    fermerOverlay("overlayRestore");
  });

  // Cocher / décocher tout
  checkAll.addEventListener("change", function () {
    toggleTousCheckboxes();
  });

  // Restaurer les sélectionnés
  btnRestaurerSelec.addEventListener("click", function () {
    restaurerSelectionnes();
  });

  // Supprimer définitivement les sélectionnés
  btnSupprimerSelec.addEventListener("click", function () {
    supprimerDefinitivementSelectionnes();
  });

  // Recherche en temps réel
  searchInput.addEventListener("input", function () {
    var resultats = filtrerEtudiants(this.value);
    afficherTableau(resultats);
  });

  // Fermer les overlays en cliquant en dehors
  overlayForm.addEventListener("click", function (e) {
    if (e.target === this) fermerOverlay("overlayForm");
  });

  overlayRestore.addEventListener("click", function (e) {
    if (e.target === this) fermerOverlay("overlayRestore");
  });

});
