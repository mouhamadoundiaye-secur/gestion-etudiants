// ===== Stores/taskStores.js — État global (données en mémoire) =====

// Compteur pour les IDs auto-incrémentés
export var nextId = 3;

// Liste des étudiants actifs
export var etudiants = [
  {
    id: 1,
    nom: "fatou",
    prenom: "diop",
    email: "fatou12@gamil.com",
    indicatif: "+221",
    telephone: "7734564746",
    role: "Design",
    actif: true
  },
  {
    id: 2,
    nom: "ndeye",
    prenom: "seye",
    email: "ndeye12@gamil.com",
    indicatif: "+221",
    telephone: "7634564747",
    role: "Marketing",
    actif: true
  }
];

// Liste des étudiants supprimés (corbeille)
export var corbeille = [];

// Incrémenter le compteur d'ID
export function incrementerId() {
  nextId++;
}
